package com.amex.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.amex.controller.dto.UserRegistrationDto;
import com.amex.model.User;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
