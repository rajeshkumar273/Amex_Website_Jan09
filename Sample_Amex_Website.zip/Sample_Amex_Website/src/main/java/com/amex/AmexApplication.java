package com.amex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AmexApplication {

	public static void main(String[] args) {
		SpringApplication.run(AmexApplication.class, args);
	}

}
